# Automated Packaging tester kit

This folder helps you write down what you find while you test Automated Packaging. An AI asks you
questions, collects evidence and writes your findings to Markdown files. You send the files to the
product team.

## What you need

- An AI tool that can read and write files in a folder, for example Claude Code or Antigravity.
  A chat AI also works: give it the link to the instructions page in the product documentation.
  It then gives you each day's file to save at the end.
- Optional: the `automated-packaging` MCP server connected to that tool, so that the AI can read
  job logs and error codes. See **AI agents (MCP)** in the product documentation.

## Set up (one time)

1. Copy this folder to your computer, for example to `C:\TesterKit`. Do not put it in the
   working directory of the product.
2. Open the folder in your AI tool as the workspace.
3. Claude Code reads `CLAUDE.md` and Antigravity reads `GEMINI.md`. Both point to `AGENTS.md`,
   which has the instructions.

## Each test session

Paste this as your first message:

```text
Read AGENTS.md and follow it. Start a findings session.
```

The AI asks who you are (the first time), which build you test, and what you test today. Then
test. Each time you notice something, tell the AI in your own words, for example:

```text
Finding: on the Images screen, Update stopped after 20 minutes with AP-HV-006.
```

When you are finished, type:

```text
I am finished for today. Close the session.
```

## What you send

Send the `findings` folder as a zip file, as your invitation says. It has one file for each day
and build, for example `2026-11-03-v0.2.32.md`, and your screenshots.

Before you send it, look at the files. They must not contain computer names, user names,
passwords or licence keys. The AI removes them, but check.

## Files

| File | What it is |
|---|---|
| `AGENTS.md` | The instructions for the AI. Do not change them |
| `CLAUDE.md`, `GEMINI.md` | Point Claude Code and Antigravity to `AGENTS.md` |
| `questions.md` | The test areas, and the questions the AI asks |
| `tester.md` | Your name and organization. The AI makes it |
| `findings/` | Your findings: one file for each day and build, with screenshots |
