# Test areas and questions

The AI shows these areas at the start of a session. For each area, it asks the questions while
you test. You do not have to answer a question that does not apply. The guides are in the
product documentation.

## 1. Install

- Did the installer start and end without an error?
- Was it clear which folder to choose for the working directory?
- Did the application start after the installation?

## 2. Prepare the host

- Did **Prepare this host** find all items that were missing?
- Was it clear what each fix does before you clicked it?
- Did you have to restart the computer? Did the product say so?

## 3. Licence

- Did you install the licence file without help?
- Was the message after the installation clear?

## 4. Stage media

- Was it clear where to get the Windows ISO and the MSIX Packaging Tool files?
- Did the product find the files that you put in the folder?
- When a file was missing, did the message say what to do?

## 5. Build an image

- Which target did you build? How long did it take?
- Did the progress tell you what was happening?
- Did the build stop with an error? Which code?

## 6. Convert an installer

- Which application did you convert? Which installer type (MSI, EXE, other)?
- Did the product find the silent install arguments, or did you have to type them?
- Did the package install and start on a test computer?
- Did anything in the application not work after you installed the package?

## 7. Sign and export

- Which certificate did you use?
- Did the signed package install on a computer that trusts the certificate?
- Did the package go to the export location you expected?

## 8. Look after images

- Did **Update** or **Rebuild** work? How long did they take?
- Was it clear what **Free up space** removes?

## 9. AI agents (MCP)

- Which client did you use? Did the connection work the first time?
- Which prompts did you try from **Example prompts**? Did the answer match the application?
- Did an agent do something that you did not expect?

## 10. Command line

- Which commands did you use?
- Were the messages and exit codes clear enough for a script?

## Closing questions (each session)

- What was the most difficult part today?
- Which message or screen did you not understand?
- What did you look for in the documentation and not find?
- Is there something that you expected the product to do and it does not do?
- On a scale from 1 to 5, how ready does this build feel for daily use? Why?
