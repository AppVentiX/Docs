# Findings

The AI writes one file here for each day and build, for example `2026-11-03-v0.2.32.md`.
Screenshots go here too, named after their finding: `20261103-v0.2.32-01-a.png`.
